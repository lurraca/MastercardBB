jQuery(function($) {

	var populateData = function() {
		window.MasterCardData = {};

		$.get("http://107.20.213.141:3000/benefits/active/all.json", function(resp) {
			var db = window.openDatabase("mastercard_db", "1.0", "Mastercard Database", 20000);
			db.transaction(
				function(tx) {
					tx.executeSql("CREATE TABLE IF NOT EXISTS data(benefits TEXT, businesses TEXT, update_id INT);");
					tx.executeSql("DELETE FROM data WHERE 1=1;");
					tx.executeSql("INSERT INTO data values('"+resp+"','',1)");
				});

			db.transaction(
				function(tx) {
					tx.executeSql("SELECT * FROM data;",[], function(tx,rs){
						MasterCardData.benefits = eval("(" + rs.rows.item(0).benefits + ")");
						MasterCardData.businesses = eval("(" + rs.rows.item(0).businesses + ")");
						alert(MasterCardData.benefits[0].name);
					});
				});
		}, "html");
	}

	var loadBenefitDetail = function(benId) {
		var ben = _.filter(MasterCardData.benefits, function(ben) {return ben.id == benId})[0];
		$("#platinum-benefits-dtl .benDtlTitle").html(ben.name);
		$("#platinum-benefits-dtl .benDtlBusiness").html(ben.name);
		$("#platinum-benefits-dtl .benDtlDescription").html(ben.description);
		$("#platinum-benefits-dtl .benDtlFrom").html(ben.begin_date);
		$("#platinum-benefits-dtl .benDtlTo").html(ben.end_date);
	}

	populateData();

	$(document).delegate("#platinum-benefits", "pageshow",function() {	
		$.each(MasterCardData.benefits, function(i,el) {
			$("#platinum-benefits-content ul")	.append("<li class='benefit-lnk' benefit-id='"+el.id+"'><a href='#platinum-benefits-dtl'>" + el.name + "</a></li>");
		});
		$("#platinum-benefits-content ul").listview('refresh');
	});

	$(".benefit-lnk").live("click", function() {
		loadBenefitDetail($(this).attr("benefit-id"));
	});
});